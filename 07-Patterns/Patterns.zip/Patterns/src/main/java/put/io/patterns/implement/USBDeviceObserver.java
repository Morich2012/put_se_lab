package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {
    private int lastUsbCount = -1; // -1 = primera vez

    @Override
    public void update(SystemState state) {
        int current = state.getUsbDevices();
        if (lastUsbCount == -1) {
            lastUsbCount = current;
            return;
        }
        if (current > lastUsbCount) {
            System.out.println("> USB device connected! Total: " + current);
        } else if (current < lastUsbCount) {
            System.out.println("> USB device disconnected! Total: " + current);
        }
        lastUsbCount = current;
    }
}